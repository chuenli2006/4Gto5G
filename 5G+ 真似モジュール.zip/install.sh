SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false

REPLACE = "/system/vendor/overlay"

print_modname() {
ui_print "********************************" 
ui_print "❗このモジュールは本当の5Gになるではない、ステータスバーにあるアイコンを変更しただけです"
ui_print "********************************"
}

on_install() {
   ui_print " 5G+ インストール中です… "
   
   ui_print "
. 
. 
. 
. 
.
+g / e / 2g / 3g / 4gおよびLTEを5G +に置き換えます
. 
. 
"
 
   ui_print " 5G+ モジュールインストール終了です、デバイスを再起動してアクティブにします。 "
   

unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}
